import axios from 'src/services/axios'

export default ({
  app,
  router,
  store,
  Vue
}) => {
  document.addEventListener("deviceready", async function () {

    updateToken()
    handleTokenRefresh()

  }, false);
}

async function updateToken() {
  let token = await getToken()
  localStorage.setItem('fcm', token);


  // Comment: Firebase token
  console.log('FCM-TOKEN: ', token)
}

function getToken() {
  // FCM: get token and store in localstorage 
  return cordova.plugins.firebase.messaging.getToken()
}

function handleTokenRefresh() {
  // FCM: On token refresh
  cordova.plugins.firebase.messaging.onTokenRefresh(async function () {
    console.log("Device token updated");
    updateToken()
  });
}
