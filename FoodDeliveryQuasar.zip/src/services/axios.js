import axios from 'axios/index'

const instance = axios.create({
  // TODO: process.env.BASE_API_URL
  baseURL: 'http://192.168.42.199:8000/api/v1',
  timeout: 3000
});


export default instance
