import axios from 'src/services/axios'


function config() {
  return {
    headers: {
      'content-type': "application/json",
      'Accept': "application/json",
      Authorization: `key=${process.env.FIREBASE_API_KEY}`,
      project_id: process.env.FIREBASE_SENDER_ID
    }
  }
}

let FCM_BASE_URL = 'https://fcm.googleapis.com/fcm'

export default (store) => {
  return {
    $store: store,
    getGroup(notificationKey) {
      return axios(Object.assign(
        config(), {
          method: "get",
          url: FCM_BASE_URL + `/notification?notification_key_name=${notificationKey}`
        }
      )).then(
        response => {
          console.log(response)
          return response
        }
      ).catch(error => {
        throw error
      })
    },
  }
}
